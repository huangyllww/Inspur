/** @file
  Dummy implement ossl_store(Store retrieval functions) for UEFI.

Copyright (c) 2019, Intel Corporation. All rights reserved.<BR>
SPDX-License-Identifier: BSD-2-Clause-Patent

**/

/*
 * This function is cleanup ossl store.
 *
 * Dummy Implement for UEFI
 */
void
ossl_store_cleanup_int (
  void
  )
{
}
